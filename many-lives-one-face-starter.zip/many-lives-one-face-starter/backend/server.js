import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";
import OpenAI, { toFile } from "openai";
import { fileURLToPath } from "url";
import { identityPrompts } from "./prompts.js";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5050;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors());
app.use(express.json({ limit: "10mb" }));

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

app.get("/", (req, res) => {
  res.json({
    message: "Many Lives of One Face backend is running."
  });
});

app.post("/api/generate", async (req, res) => {
  try {
    const { identityId } = req.body;

    if (!identityId) {
      return res.status(400).json({
        success: false,
        error: "Missing identityId."
      });
    }

    const selectedIdentity = identityPrompts[identityId];

    if (!selectedIdentity) {
      return res.status(404).json({
        success: false,
        error: "Identity concept not found."
      });
    }

    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({
        success: false,
        fallback: true,
        error: "Missing OpenAI API key. Showing curated gallery image instead."
      });
    }

    const baseFacePath = path.join(__dirname, "base_face.png");

    if (!fs.existsSync(baseFacePath)) {
      return res.status(500).json({
        success: false,
        fallback: true,
        error: "Base face image not found in backend folder."
      });
    }

    const finalPrompt = `
Use the uploaded face image as the identity reference.

${selectedIdentity.prompt}

Keep the portrait composition consistent with a digital gallery series.
The result should be polished, respectful, and suitable for an AI art final project.
`;

    const response = await openai.images.edit({
      model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-2",
      image: await toFile(fs.createReadStream(baseFacePath), "base_face.png", {
        type: "image/png"
      }),
      prompt: finalPrompt,
      size: "1024x1024",
      quality: "low"
    });

    const imageBase64 = response.data?.[0]?.b64_json;

    if (!imageBase64) {
      return res.status(500).json({
        success: false,
        fallback: true,
        error: "No image returned from AI API."
      });
    }

    res.json({
      success: true,
      title: selectedIdentity.title,
      promptUsed: finalPrompt,
      image: `data:image/png;base64,${imageBase64}`
    });
  } catch (error) {
    console.error("Generation error:", error);

    res.status(500).json({
      success: false,
      fallback: true,
      error: "Live generation failed. Showing curated gallery image instead."
    });
  }
});

app.listen(PORT, () => {
  console.log(`Backend running at http://localhost:${PORT}`);
});
